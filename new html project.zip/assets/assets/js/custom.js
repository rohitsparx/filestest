
function tab( view_id , view_detail_id)
{	this.view_id=view_id;
	this.view_detail_id=view_detail_id;

	$(view_detail_id).children().hide();
	$(view_detail_id).children(':eq(0)').show();
	$(view_id).children(':eq(0)').addClass('active');

	$(view_id).children().click(function(e){
	e.preventDefault();
	if(!$(this).hasClass("active")){
	var no= $(this).index();
	$(view_detail_id).children().dequeue().css({'opacity' : '1.0'}).hide();
	$(view_detail_id).children(':eq('+no+')').fadeIn();
	$(view_id).children().removeClass('active');
	$(this).addClass('active');
	}});
}

$(function()
{
    new tab('nav ul.nav' , '.tab-contents');
    
    $("#color-picked").spectrum({// for colorpicker of background color
        color: "#ffffff",
        //flat: true,//Flat This means that it will always show up at full size
        showAlpha: false,
        showInitial: true,
        showInput: true,
        chooseText: "Ok",
        cancelText: "Cancel",
        preferredFormat: "hex",
        move: function(color) {
            color.toHexString();//alert(color.toHexString()); // #ff0000
        },
        show: function(color) {
            color.toHexString(); // #ff0000
        }
    });
    
    $("#bg-color-picked").spectrum({// for colorpicker of background color
        color: "#ffffff",
        //flat: true,//Flat This means that it will always show up at full size
        showAlpha: false,
        showInitial: true,
        showInput: false,
        chooseText: "Ok",
        cancelText: "Cancel",
        preferredFormat: "hex",
        move: function(color) {
            color.toHexString();//alert(color.toHexString()); // #ff0000
        },
        show: function(color) {
            color.toHexString(); // #ff0000
        }
    });
    
});